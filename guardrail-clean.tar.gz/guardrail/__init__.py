"""
GuardRail - Security testing for AI agents

Keep your AI agents on the right track.
"""

__version__ = "0.1.0"
